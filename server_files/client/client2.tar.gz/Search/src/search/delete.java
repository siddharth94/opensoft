/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

/**
 *
 * @author drishti
 */
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.util.ArrayList;
import java.util.HashMap;
import java.util.Iterator;

/**
 *
 * @author drishti
 */
public class delete {
    static void deleteByHits() throws FileNotFoundException, IOException, ClassNotFoundException{
        globals.size = getFolderSize.folderSize(new File("data"));
        globals.download_size = globals.downloadList.get(0).size;
        while(((globals.size+globals.download_size)/(1024*1024))>256){
            InputStream inputHitsFile = new FileInputStream("hits.js");
            InputStream inputHitsBuffer = new BufferedInputStream(inputHitsFile);
            ObjectInput inputHits = new ObjectInputStream (inputHitsBuffer); 
            HashMap< Integer, ArrayList<Object> > hitsList =(HashMap)inputHits.readObject();
            Iterator it = hitsList.entrySet().iterator();
            String location = "null";
            int minimum = 1000000;
            for(Integer key: hitsList.keySet()){
                ArrayList< Object> temp = hitsList.get(key);
                if((Integer)temp.get(0)<minimum){
                    location = (String)temp.get(1);
                }
            }
            File file = new File(location);
            file.delete();
            globals.size = getFolderSize.folderSize(new File("/data"));
        }
    }
}

