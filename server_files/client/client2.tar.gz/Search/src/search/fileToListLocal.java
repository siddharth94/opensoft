/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

/**
 *
 * @author drishti
 */
import java.io.BufferedInputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author drishti
 */
public class fileToListLocal {
    static void turn() throws FileNotFoundException, IOException, ClassNotFoundException{
        InputStream inputFile = new FileInputStream("local.js");
        InputStream inputBuffer = new BufferedInputStream(inputFile);
        ObjectInput input = new ObjectInputStream (inputBuffer);
        JSONArray got = (JSONArray)input.readObject();
        for(int i=0;i<got.size();i++){
            localPacket temp =new localPacket();
            JSONObject tmp =  (JSONObject) got.get(i);
            temp.category = (String) tmp.get("category");
            temp.extension = (String) tmp.get("extension");
            temp.id = Integer.parseInt((String) tmp.get("id"));
            temp.modified = (String)tmp.get("modified");
            temp.name = (String) tmp.get("file_name");
            temp.priority = (int) tmp.get("priority");
            temp.size = (long) tmp.get("size");
            globals.localList.add(temp);
        }
        input.close();
        inputFile.close();
        inputBuffer.close();
    }
}

