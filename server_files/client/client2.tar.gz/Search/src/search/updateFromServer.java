/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import com.sun.corba.se.impl.orbutil.ObjectWriter;
import java.io.BufferedInputStream;
import java.io.BufferedOutputStream;
import java.io.FileInputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.InputStream;
import java.io.ObjectInput;
import java.io.ObjectInputStream;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.List;
import opensoft.common.ClientObjectToSend;
import opensoft.common.FileAttribute;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author drishti
 */
public class updateFromServer {
    public static void update() throws ClassNotFoundException, FileNotFoundException, IOException{
            InputStream inputFile = new FileInputStream("update.lg");
            InputStream inputBuffer = new BufferedInputStream(inputFile);
            ObjectInput input = new ObjectInputStream (inputBuffer);
            
                int currentVersion = Integer.parseInt((String)input.readObject()); 
                System.out.println(",io"+currentVersion);
                inputFile.close();
                inputBuffer.close();
                input.close();
                ClientObjectToSend updateClient = Client.sendItemList(currentVersion);
                List<FileAttribute> updateList = updateClient.list;//send version to echo port
                currentVersion = updateClient.updateVersion;
                System.out.println(updateClient);
                if(updateList.size()>0){
                    try{
                        System.out.println("update hete");
                        fileToListGlobal.turn();
                            fileToListLocal.turn();
                            System.out.println(updateList);
                            int len;
                            if(globals.serverList!=null){
                                 len = globals.serverList.size();}
                            else{
                                len=0;
                            }
                            for(int j=0;j<updateList.size();j++){
                                for(int i =0; i< len;i++){
                                    if(updateList.get(j).id == (globals.serverList.get(i)).id){
                                        if(updateList.get(j).action.equals("deleted")){
                                            globals.serverList.remove(i);
                                        }
                                    }
                                }
                                if(updateList.get(j).action.equals("created")){
                                    System.out.println(updateList.get(j).id);
                                    serverPacket add = new serverPacket();
                                    add.id = updateList.get(j).id;
                                            add.name = updateList.get(j).name;
                                            add.extension = updateList.get(j).extension;
                                            add.size = updateList.get(j).size;
                                            System.out.println("Category while adding to ser list"+updateList.get(j).category);
                                            add.category = updateList.get(j).category;
                                            globals.serverList.add(add);
                                        }
                                    }
                            System.out.println(globals.localList.size() +"lcal size" );
                            if(globals.localList!=null){
                            for(FileAttribute o : updateList){
                                for(int i =0; i< globals.localList.size();i++){
                                    if(o.id == (globals.localList.get(i)).id && o.action.equals("modified")){
                                        globals.localList.get(i).modified = "1";
                                    }
                                }
                            }}
                        }
                        catch(IOException e){}
                    }
                OutputStream outputFile = new FileOutputStream("update.lg");
                OutputStream outputBuffer = new BufferedOutputStream(outputFile);
                ObjectOutput output = new ObjectOutputStream(outputBuffer); 
                String curr = new String();
                curr = curr+ currentVersion;
                System.out.println(curr);
                output.writeObject(curr);
                output.close();
                outputFile.close();
                outputBuffer.close();
                    listToFileLocal.turn();
                    listToFileServer.turn();
            
    }
}

