/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import java.io.*;
import java.net.Socket;

import opensoft.common.ClientObjectToSend;
import opensoft.common.FileClass;
/**
 *
 * @author drishti
 */
public class Client {
    	public static Socket getConn() {
		try {
			Socket conn = new Socket(ClientConstants.IPADDRESS,
					ClientConstants.port);
			return conn;
		} catch (IOException e) {
			e.printStackTrace();
			return null;
		}
	}

	public static ClientObjectToSend sendItemList(int updateId) {
                System.out.println("Got version from client"+updateId);
		ClientObjectToSend obj = new ClientObjectToSend();
		obj.reqType = ClientConstants.REQTYPE2;
		obj.fileId=updateId;
		Socket socket = getConn();
		try {
			ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
			writer.flush();
			writer.writeObject(obj);
			obj = (ClientObjectToSend) reader.readObject();
			System.out.println(obj.list);
			reader.close();
			writer.close();
                        for(int i=0;i<obj.list.size();i++){
                            System.out.println(obj.list.get(i));
                        }
			return obj;
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
	}
	
	public static FileClass downloadFile(int fileId){
                System.out.println("FileID"+fileId);
		ClientObjectToSend obj = new ClientObjectToSend();
		obj.reqType=ClientConstants.REQTYPE1;
		obj.fileId=fileId;
		Socket socket = getConn();
		try {
			ObjectInputStream reader = new ObjectInputStream(socket.getInputStream());
			ObjectOutputStream writer = new ObjectOutputStream(socket.getOutputStream());
			writer.flush();
			writer.writeObject(obj);
			obj = (ClientObjectToSend) reader.readObject();
			reader.close();
			writer.close();
			return obj.downloadedFile;
		} catch (IOException | ClassNotFoundException e) {
			e.printStackTrace();
			return null;
		}
		
	}

	public static boolean storeFile(FileClass file, String path){
		String dir=path;
		String []temp= dir.split("/");
		dir=dir.substring(0, path.length()-temp[temp.length-1].length());
		File dirPtr=new File(dir);
		if(!dirPtr.exists())
			dirPtr.mkdirs();
		File fileptr = new File(path);
		try {
			if(file==null)
				return false;
			FileOutputStream foStream = new FileOutputStream(fileptr);
			foStream.write(file.fileData);
			foStream.close();
			return true;
		} catch (IOException e) {
			return false;
		}
	}
	
	/*public static void main(String[] args) {
		ClientObjectToSend obj=sendItemList(6);
		boolean testvalue=storeFile(downloadFile(1), "./test/text.txt");
		System.out.println(testvalue);
		System.out.println("Client Completed");
	} */

}
