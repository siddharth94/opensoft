/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author drishti
 */
public class listToFileServer {
    static void turn() throws FileNotFoundException, IOException{
       OutputStream outputFile = new FileOutputStream("server.js");
        OutputStream outputBuffer = new BufferedOutputStream(outputFile);
        ObjectOutput output = new ObjectOutputStream(outputBuffer);            
        JSONArray send = new JSONArray();
        if(globals.serverList !=null){
        for(int i=0;i<globals.serverList.size();i++){
            JSONObject tmp =  new JSONObject();
            serverPacket temp = globals.serverList.get(i);
            System.out.println(temp.category+"before addng to file");
            tmp.put("category",temp.category) ;
            tmp.put("change",temp.change);
            tmp.put("extension",temp.extension);
            tmp.put("id",""+(temp.id));
            System.out.println("is sent ot server"+temp.id);
            tmp.put("file_name", temp.name);
            tmp.put("priority", ""+temp.priority);
            tmp.put("size",""+temp.size);
            send.add(tmp);
            System.out.println(tmp.toString()+"tmp value before adding to file");
        }
        System.out.println(send.toString());
        output.writeObject(send);
        output.close();
        outputFile.close();
        outputBuffer.close();
        }
    }
}

