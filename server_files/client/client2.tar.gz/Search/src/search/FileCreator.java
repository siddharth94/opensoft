/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import java.io.BufferedOutputStream;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import java.util.ArrayList;
import java.util.HashMap;
import org.json.simple.JSONArray;

/**
 *
 * @author sidgupta
 */
public class FileCreator {
    
    FileCreator() throws IOException
    {
        String command = "mkdir data";
        Process p;
        p = Runtime.getRuntime().exec(command);
        JSONArray temp = new JSONArray();
        HashMap <Integer, ArrayList <Object> > temphash = new HashMap <Integer, ArrayList <Object> >();
        String cur = new String();
        cur = cur + "0";
        System.out.println("hell" + cur);

        try (
            OutputStream file = new FileOutputStream("hits.js");
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
          ){
            output.writeObject(temphash);
            buffer.close();
            file.close();
            output.close();
          }  
          catch(IOException ex){
            throw ex;
          }
        try (
            OutputStream file = new FileOutputStream("local.js");
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
          ){
            output.writeObject(temp);
            buffer.close();
            file.close();
            output.close();
          }  
          catch(IOException ex){
            throw ex;
          }
        try (
            OutputStream file = new FileOutputStream("server.js");
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
          ){
            output.writeObject(temp);
            buffer.close();
            file.close();
            output.close();
          }  
          catch(IOException ex){
            throw ex;
          }

        try (
            OutputStream file = new FileOutputStream("toGet.js");
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
          ){
            output.writeObject(temp);
            buffer.close();
            file.close();
            output.close();
          }  
          catch(IOException ex){
            throw ex;
          }        
        try (
            OutputStream file = new FileOutputStream("update.lg");
            OutputStream buffer = new BufferedOutputStream(file);
            ObjectOutput output = new ObjectOutputStream(buffer);
          ){
            System.out.println(cur);
            output.writeObject(cur);
            buffer.close();
            file.close();
            output.close();
          }  
          catch(IOException ex){
            throw ex;
          } 
    }
    
}
