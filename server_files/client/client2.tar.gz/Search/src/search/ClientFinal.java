/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;
import java.io.BufferedInputStream;
import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.io.OutputStream;
import java.net.ServerSocket;
import java.net.Socket;
import java.net.InetAddress;
import java.net.*;
import java.io.*;
import java.io.FileNotFoundException;
import java.io.FileReader;
import java.util.Iterator;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import java.util.Arrays;
import java.util.Comparator;
import java.util.*;
import java.util.logging.*;
import opensoft.common.*;

class serverPacket {     //expected form of json object
    public String name;
    public String category;
    public int priority;
    public long size;
    public String extension;
    public int id;
    public String change;
}

//class hits{
//    public int id;
//    public int hits;
//    public String location;
//}

class localPacket{
    public String name;
    public String category;
    public int priority;
    public long size;
    public String extension;
    public int id;
    public String modified;
    public String location;
}

class toGet{
    public String file_name;
    public String id;
    public int priority;
    public long size;
    public String extension;
    public String category;
}

class globals {
    /*public int SOCKET_PORT = 8080;
    public String SERVER = "127.0.0.1";  // localhost*/
    public String FILE_TO_RECEIVED ;   
    public int FILE_SIZE ;
    public static ArrayList<toGet> downloadList = new ArrayList<>();
    public static ArrayList<localPacket> localList = new ArrayList<>();
    public static ArrayList<serverPacket> serverList =new ArrayList<>();
    public static long size;
    public static long download_size;
}

class mainThread implements Runnable {               //main thread definition
   private Thread t;
   
   mainThread( ){
       
   }
   
   public void run() {
       while(true){
           
           globals port = null;
           Socket sock;
           int currentVersion;
           try{
                sock = Client.getConn();
                System.out.println("working till");
                if(sock == null) 
                {
                    throw new SocketException();
                }
                sock.close();
                updateFromServer.update( );
                           fileToListDownload.turn();
                           if(globals.downloadList!=null && globals.downloadList.size()!=0){
                           System.out.println(globals.downloadList.get(0).priority);
                           int downloadLen = globals.downloadList.size();
                           System.out.println("number to download"+downloadLen);
                           Comparator comparePair = new Comparator <toGet>() {
                                @Override public int compare(toGet o1, toGet o2) { 
                                    return (int)((long)(o2.priority) - (long)(o1.priority));
                                }
                            };
                            Collections.sort(globals.downloadList, comparePair);
                            System.out.println("Size before thru loop"+globals.downloadList.size());
                            for(int i=0;i< globals.downloadList.size();i++){
                                delete.deleteByHits();
                                System.out.println("FIle id clint"+globals.downloadList.get(i).id);
                                String location = "./data/"+globals.downloadList.get(i).category+"/" +globals.downloadList.get(i).file_name +"."+ globals.downloadList.get(i).extension;
                                boolean through = Client.storeFile( Client.downloadFile(Integer.parseInt(globals.downloadList.get(i).id)),location);
                                System.out.println("Through:"+through + "and loc:" + location);
                                if(through == false){
                                    Thread.sleep(5000);
                                    break;
                                }
                                else{
                                    fileToListLocal.turn();
                                    localPacket mytemp = new localPacket();
                                    mytemp.category = globals.downloadList.get(i).category;
                                    mytemp.extension = globals.downloadList.get(i).extension;
                                    mytemp.id = Integer.parseInt(globals.downloadList.get(i).id);
                                    mytemp.name = globals.downloadList.get(i).file_name;
                                    mytemp.size = globals.downloadList.get(i).size;
                                    mytemp.modified = "0";
                                    mytemp.location = location;
                                    globals.localList.add(mytemp);
                                    for(int j=0;j<globals.localList.size();j++){
                                        if(Integer.parseInt(globals.downloadList.get(i).id) == globals.localList.get(j).id){
                                            globals.localList.get(i).modified = "0";
                                        }
                                    }
                                    listToFileLocal.turn();
                                    for(int j=0;j<globals.downloadList.size();j++){
                                        if(globals.downloadList.get(j).id == globals.downloadList.get(i).id){
                                            globals.downloadList.remove(j);
                                        }
                                    }
                                }
                            }
                            //System.out.println(globals.downloadList.get(0).priority);
                           downloadLen = globals.downloadList.size();
                           System.out.println("number to downloadend"+downloadLen);
                            listToFileDownload.turn();
                        }
            }
           catch( SocketException e){
               try {
                   Thread.sleep(5000);  //no connection try again after time
               } catch (InterruptedException ex) {
                   Logger.getLogger(mainThread.class.getName()).log(Level.SEVERE, null, ex);
               }
           }
           catch (UnknownHostException e){} catch (IOException ex) { 
               Logger.getLogger(mainThread.class.getName()).log(Level.SEVERE, null, ex);
           } catch (ClassNotFoundException ex) {
               Logger.getLogger(mainThread.class.getName()).log(Level.SEVERE, null, ex);
           } catch (InterruptedException ex) {
               Logger.getLogger(mainThread.class.getName()).log(Level.SEVERE, null, ex);
           } 
        try {
               //To read the json text file into array
               Thread.sleep(5000);
           } catch (InterruptedException ex) {
               Logger.getLogger(mainThread.class.getName()).log(Level.SEVERE, null, ex);
           }
       }
   }
    /*public void start ()
   {
       System.out.println("in start outside if");
       if(t==null){ 
       t=new Thread();
           t.start();
           System.out.println("in start if block");
       }
   }*/
}
public class ClientFinal {
    
    ClientFinal()
    {
        mainThread R1 = new mainThread();
//        R1.start(); 
    }
    
}
