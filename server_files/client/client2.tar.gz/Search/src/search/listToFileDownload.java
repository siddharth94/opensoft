/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

import java.io.BufferedOutputStream;
import java.io.FileNotFoundException;
import java.io.FileOutputStream;
import java.io.IOException;
import java.io.ObjectOutput;
import java.io.ObjectOutputStream;
import java.io.OutputStream;
import org.json.simple.JSONArray;
import org.json.simple.JSONObject;

/**
 *
 * @author drishti
 */
public class listToFileDownload {
    static void turn() throws FileNotFoundException, IOException{
        OutputStream outputFile = new FileOutputStream("toGet.js");
        OutputStream outputBuffer = new BufferedOutputStream(outputFile);
        ObjectOutput output = new ObjectOutputStream(outputBuffer);            
        JSONArray send = new JSONArray();
        for(int i=0;i<globals.downloadList.size();i++){
            JSONObject tmp =  new JSONObject();
            toGet temp = globals.downloadList.get(i);
            tmp.put("category",temp.category) ;
            tmp.put("extension",temp.extension);
            tmp.put("id",""+(temp.id));
            tmp.put("file_name", temp.file_name);
            tmp.put("priority", ""+temp.priority);
            tmp.put("size",""+temp.size);
            send.add(tmp);
            System.out.println(tmp.toString());
        }
        for (int i=0; i<send.size(); i++)
        {
            System.out.println(send.get(i).toString());
        }
        globals.downloadList.clear();
        output.writeObject(send);
        output.close();
        outputFile.close();
        outputBuffer.close();
    }
}

