/*
 * To change this license header, choose License Headers in Project Properties.
 * To change this template file, choose Tools | Templates
 * and open the template in the editor.
 */
package search;

/**
 *
 * @author sidgupta
 */
public class ClientConstants {
	public static String IPADDRESS="172.27.30.64";
	public static Integer port=1235;
	public static final String REQTYPE1="download";
	public static final String REQTYPE2="list_exchange";
	public static final String DELIMITER="</delimiter/>";    
}
