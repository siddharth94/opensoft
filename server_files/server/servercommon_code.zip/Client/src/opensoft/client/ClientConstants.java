package opensoft.client;

public class ClientConstants {
	public static String IPADDRESS="172.27.30.64";
	public static Integer port=1235;
	public static final String REQTYPE1="download";
	public static final String REQTYPE2="list_exchange";
	public static final String DELIMITER="</delimiter/>";
}
