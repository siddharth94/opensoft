package opensoft.server.main;

import java.io.File;
import java.io.FileInputStream;
import java.io.IOException;
import java.util.ArrayList;

import org.json.simple.JSONArray;
import org.json.simple.JSONObject;
import org.json.simple.parser.JSONParser;
import org.json.simple.parser.ParseException;
import org.jsoup.Jsoup;
import org.jsoup.nodes.Document;
import org.jsoup.nodes.Element;

import opensoft.common.ClientObjectToSend;
import opensoft.common.FileAttribute;
import opensoft.common.FileClass;


public class BackendService {
	public static FileClass getFile(int fileId){
		FileClass file = new FileClass();
		String request=Constants.URL+"?type=1&id="+fileId;
		Document doc=null;
		try {
			doc = (Document) Jsoup.connect(request).userAgent(Constants.AGENT).timeout(Constants.TIMEOUT).get();
		} catch (IOException e1) {
			return null;
		}
		Element element =  doc.body();
		String filenamewithpath=element.text();
		if(filenamewithpath.equals("404"))
			return null;
		else 
			filenamewithpath = Constants.BASE_FILE_LOCATION+filenamewithpath;
		File filePtr = new File(filenamewithpath);
		try {
			FileInputStream fstream = new FileInputStream(filePtr);
			file.fileData= new byte[(int)filePtr.length()];
			fstream.read(file.fileData);
			fstream.close();
			return file;
		} catch (IOException e) {
			Log.logWriter("Error while geting filelocation from backend for file id= " + fileId + 
					" in BackendService.getFile()");
			return null;
		} 
	}
	
	public static  ClientObjectToSend updateList(ClientObjectToSend obj){
		try {
			obj.list=new ArrayList<FileAttribute>();
			String request=Constants.URL+"?type=0&id="+obj.fileId;
			Document doc=Jsoup.connect(request).userAgent(Constants.AGENT).timeout(Constants.TIMEOUT).get();
			Element element =  doc.body();
			String list = element.text();
			JSONParser jparse = new JSONParser(); 
			Object tempObj  = jparse.parse(list);
			JSONObject jobject  = (JSONObject)tempObj;
			obj.length= Integer.parseInt(jobject.get("length").toString());
			obj.created= Integer.parseInt(jobject.get("created").toString());
			obj.deleted= Integer.parseInt(jobject.get("deleted").toString());
			obj.modified= Integer.parseInt(jobject.get("modified").toString());
			obj.updateVersion= Integer.parseInt(jobject.get("id").toString());
			JSONArray ulist = (JSONArray)jobject.get("list");			
			for(int i=0;i<ulist.size();i++){
				FileAttribute fileAttribute = new FileAttribute();
				jobject=(JSONObject)ulist.get(i);
				fileAttribute.action = jobject.get("action").toString();
				fileAttribute.id=Integer.parseInt(jobject.get("id").toString());
				if(fileAttribute.action.equals("modified") || fileAttribute.action.equals("deleted"));
				else {
					
					fileAttribute.extension= jobject.get("extension").toString();
					fileAttribute.category= jobject.get("category").toString();
					fileAttribute.name= jobject.get("name").toString();
					fileAttribute.size= Long.parseLong(jobject.get("size").toString());
				}
				obj.list.add(fileAttribute);				
			}
			return obj;
		} catch (ParseException | IOException e) {
			Log.logWriter("Exception in : BackendService.ClientObjectToSend()");
			return obj;
		}
		
	}
	
	
}
