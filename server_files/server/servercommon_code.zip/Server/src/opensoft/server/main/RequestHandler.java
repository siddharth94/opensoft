package opensoft.server.main;

import java.io.*;
import java.net.Socket;

import opensoft.common.ClientObjectToSend;



public class RequestHandler implements Runnable{
	public  Socket socket;
	RequestHandler(Socket socket){
		this.socket=socket;
	}
	@Override
	public void run() {
		try {
			ObjectOutputStream writer= new ObjectOutputStream(socket.getOutputStream());
			writer.flush();
			ObjectInputStream reader= new ObjectInputStream(socket.getInputStream());
			ClientObjectToSend cReq = (ClientObjectToSend) reader.readObject();
			String reqType = cReq.reqType;
			if(reqType.equals(Constants.REQUEST1)){ //download request
				cReq.downloadedFile=BackendService.getFile(cReq.fileId);
				writer.writeObject(cReq);
			}
			else if(reqType.equals(Constants.REQUEST2)){ //list Exchange request
				cReq=BackendService.updateList(cReq);
				writer.writeObject(cReq);
			}
			Log.logWriter("Response sent to Client with address " + socket.getInetAddress());
			reader.close();
			writer.close();
		} catch (IOException | ClassNotFoundException e) {
			Log.logWriter("IO Exception occured in : RequestHandler.run()");
		} 
		
	}
	
}
