package opensoft.server.main;

public class Constants {

	public static final Integer PORT=1235;
	public static final String LOGDIR="./Logs/";
	public static final String LOGFILENAME = "log.txt";
	public static final String REQUEST1= "download";
	public static final String REQUEST2="list_exchange";
	public static final String DELIMITER="</delimiter/>";
	public static final String URL="http://172.27.30.64/opensoft/index.php";
	public static final String BASE_FILE_LOCATION = "./"; 
	public static final String AGENT="Mozilla/5.0";
	public static final int TIMEOUT = 5000;
}
