package opensoft.server.main;

import java.io.IOException;
import java.net.ServerSocket;
import java.net.Socket;

public class MainServer {

	public static ServerSocket getSocket(){
		try {
			ServerSocket serverSocket=new ServerSocket(Constants.PORT);
			return serverSocket;
			} catch (IOException ex) {
				ex.printStackTrace();
				Log.logWriter("Exception while creating server socket: MainServer.getSocket()");
				Log.logWriter(ex.getStackTrace().toString());
				return null;
		}
	}
	
	public static void main(String[] args) {
		ServerSocket serverSock = getSocket();
		Socket socket;
		if(serverSock!=null){
			System.out.println("Server Started.......");
			while(true){
				try {
					socket = serverSock.accept();
					Log.logWriter("Received request from Client with Address = "+socket.getInetAddress());
					Thread thread = new Thread(new RequestHandler(socket));
					thread.start();
					
				} catch (IOException e) {
					Log.logWriter("Exception thrown by serverSock.accept(): MainServer.main()");
				}
			}
		}
	}

}
