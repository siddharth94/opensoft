package opensoft.server.main;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileWriter;
import java.io.IOException;
import java.text.*;
import java.util.Date;

public class Log {
	public static String logFileName=Constants.LOGDIR+Constants.LOGFILENAME;
	
	public static File getFile(){
		if(!new File(Constants.LOGDIR).exists())
			new File(Constants.LOGDIR).mkdirs();
		File file= new File(logFileName);
		try{
			if(!file.exists()){
				file.createNewFile();
			}
			return file;
		} catch(SecurityException | IOException ex){
			System.out.println("Not to able to create log file because of file permission \n"
					+ "please assign the read and write access to the log file directory"
					+ ":Log.getFile()");
			ex.printStackTrace();
			return null;
		}
	}
	
	synchronized public static void logWriter(String msg){
		try {
			DateFormat df = new SimpleDateFormat("dd/MM/yy HH:mm:ss");
		    Date dateobj = new Date();
			FileWriter fw = new FileWriter(getFile(), true);
			BufferedWriter writer= new BufferedWriter(fw);
			writer.write(msg+'\t'+df.format(dateobj)+'\n');
			writer.close();
		} catch (IOException e) {
			System.out.println("Not able to write in log file : Log.logWriter()");
		}
	}
}
