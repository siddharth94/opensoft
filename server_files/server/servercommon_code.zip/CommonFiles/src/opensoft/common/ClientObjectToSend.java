package opensoft.common;

import java.io.Serializable;
import java.util.*;

public class ClientObjectToSend implements Serializable{
	private static final long serialVersionUID = 1L;
		public String reqType;
		public List<FileAttribute> list;
		public int fileId;
		public int length;
		public int modified;
		public int created;
		public int deleted;
		public int updateVersion;
		public FileClass downloadedFile=null;
}