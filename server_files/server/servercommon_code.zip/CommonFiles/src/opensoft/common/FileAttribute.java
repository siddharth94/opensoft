package opensoft.common;

import java.io.Serializable;

public class FileAttribute implements Serializable{
	private static final long serialVersionUID = 1L;
	public String name;
	public String category;
	public int id;
	public String extension;
	public long size;
	public String action;
}