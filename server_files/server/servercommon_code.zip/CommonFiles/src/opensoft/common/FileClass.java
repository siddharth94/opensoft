package opensoft.common;

import java.io.Serializable;

public class FileClass implements Serializable{
	
	private static final long serialVersionUID = 1L;
	public byte[] fileData;	
}
